package com.flowedge.app

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.withFrameNanos
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs

private val Context.flowPrefs by preferencesDataStore(name = "flowedge_settings")
private val KEY_ENABLED = booleanPreferencesKey("enabled")
private val KEY_FLIP = booleanPreferencesKey("flip_enabled")
private val KEY_BRIGHTNESS = floatPreferencesKey("brightness")

class MainActivity : ComponentActivity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var flipEnabled = false
    private var systemEnabled = true
    private var upsideDownSince = 0L
    private var lastFlipTrigger = 0L
    private var onFlipDetected: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        setContent {
            FlowEdgeApp(
                onFlipSettingChanged = { flipEnabled = it; updateSensorRegistration() },
                onMasterChanged = { systemEnabled = it; updateSensorRegistration() },
                setFlipCallback = { onFlipDetected = it },
                sensorAvailable = accelerometer != null
            )
        }
    }

    private fun updateSensorRegistration() {
        sensorManager.unregisterListener(this)
        if (flipEnabled && systemEnabled && accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        val e = event ?: return
        if (e.sensor.type != Sensor.TYPE_ACCELEROMETER || !flipEnabled || !systemEnabled) return
        // Screen-down: gravity points approximately toward the display, so z is strongly negative on many devices.
        // Use a broad threshold and a dwell period to avoid reacting to brief movement.
        val now = System.currentTimeMillis()
        val down = e.values[2] < -7.5f && abs(e.values[0]) < 5.5f && abs(e.values[1]) < 5.5f
        if (down) {
            if (upsideDownSince == 0L) upsideDownSince = now
            if (now - upsideDownSince >= 1000 && now - lastFlipTrigger > 5000) {
                lastFlipTrigger = now
                onFlipDetected?.invoke()
            }
        } else upsideDownSince = 0L
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
    override fun onResume() { super.onResume(); updateSensorRegistration() }
    override fun onPause() { sensorManager.unregisterListener(this); super.onPause() }
}

private enum class Show(val label: String, val subtitle: String, val kind: Int) {
    TWIN_DROP("Twin Drop", "Dos barras en espejo", 0),
    QUADRA("Quadra", "Cuatro bloques coordinados", 1),
    PRISM("Prism Shift", "Geometría multicolor", 2),
    NEON_PULSE("Neon Pulse", "Pulsos sincronizados", 3),
    CHROMA("Chroma Fall", "Bloques descendentes", 4),
    MIRROR("Mirror Grid", "Patrones reflejados", 5),
    MINIMAL("Minimal", "Luz discreta", 6),
    SPECTRUM("Spectrum", "Secuencias de color", 7)
}

@Composable
private fun FlowEdgeApp(
    onFlipSettingChanged: (Boolean) -> Unit,
    onMasterChanged: (Boolean) -> Unit,
    setFlipCallback: ((() -> Unit) -> Unit),
    sensorAvailable: Boolean
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs by context.flowPrefs.data.map { p -> Triple(p[KEY_ENABLED] ?: true, p[KEY_FLIP] ?: false, p[KEY_BRIGHTNESS] ?: 0.62f) }.collectAsState(initial = Triple(true, false, 0.62f))
    var enabled by remember { mutableStateOf(true) }
    var flipEnabled by remember { mutableStateOf(false) }
    var brightness by remember { mutableFloatStateOf(0.62f) }
    var speed by remember { mutableFloatStateOf(0.55f) }
    var activeShow by remember { mutableStateOf(Show.WATERFALL) }
    // The first launch should demonstrate the actual light effect, not a blank black preview.
    var demo by remember { mutableStateOf(true) }

    LaunchedEffect(prefs) {
        enabled = prefs.first
        flipEnabled = prefs.second
        brightness = prefs.third
        onMasterChanged(enabled)
        onFlipSettingChanged(flipEnabled)
    }
    setFlipCallback { if (enabled && flipEnabled) demo = !demo }

    val cyan = Color(0xFF50F5FF)
    val muted = Color(0xFF83909E)
    MaterialTheme(colorScheme = darkColorScheme(
        background = Color(0xFF030508), surface = Color(0xFF0B1017), surfaceVariant = Color(0xFF111923),
        primary = cyan, secondary = Color(0xFFB76CFF), onBackground = Color(0xFFF4F8FC),
        onSurface = Color(0xFFF4F8FC), onSurfaceVariant = muted
    )) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF030508)) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("FLOWEDGE", color = cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                        Text("Light, in motion.", fontSize = 27.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.8).sp)
                    }
                    Row(
                        Modifier.clip(RoundedCornerShape(30.dp)).background(Color(0xFF0D1B20)).padding(horizontal = 11.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(Modifier.size(6.dp).clip(RoundedCornerShape(50)).background(if (enabled && demo) cyan else muted))
                        Text(if (enabled && demo) "LIVE" else "PAUSED", fontSize = 10.sp, letterSpacing = 1.3.sp, color = if (enabled && demo) cyan else muted, fontWeight = FontWeight.Bold)
                    }
                }

                // Hero preview: the display center remains true black while the rails animate.
                Box(
                    Modifier.fillMaxWidth().height(310.dp).clip(RoundedCornerShape(28.dp))
                        .background(Color.Black)
                ) {
                    EdgeShowCanvas(show = activeShow, enabled = enabled && demo, brightness = brightness, speed = speed, modifier = Modifier.fillMaxSize())
                    Column(Modifier.align(Alignment.TopStart).padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("AMOLED PREVIEW", fontSize = 9.sp, letterSpacing = 2.2.sp, color = Color(0xFFB7C5D1), fontWeight = FontWeight.Bold)
                        Text(activeShow.label.uppercase(), fontSize = 11.sp, letterSpacing = 1.4.sp, color = cyan)
                    }
                    if (!demo || !enabled) {
                        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("◌", fontSize = 30.sp, color = cyan)
                            Text("Luz en pausa", fontSize = 13.sp, color = Color(0xFF8A98A8))
                        }
                    }
                    Text("PURE BLACK · EDGE LIGHT", Modifier.align(Alignment.BottomCenter).padding(bottom = 14.dp), color = Color(0xFF627281), fontSize = 9.sp, letterSpacing = 1.7.sp)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { demo = !demo }, enabled = enabled, modifier = Modifier.weight(1f).height(50.dp),
                        shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = cyan, contentColor = Color(0xFF001014))
                    ) { Text(if (demo) "Ⅱ   Pausar show" else "▶   Iniciar show", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                    OutlinedButton(
                        onClick = {
                            enabled = !enabled
                            if (!enabled) demo = false
                            onMasterChanged(enabled)
                            scope.launch { context.flowPrefs.edit { it[KEY_ENABLED] = enabled } }
                        },
                        modifier = Modifier.size(width = 54.dp, height = 50.dp), shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF26333F))
                    ) { Text(if (enabled) "●" else "○", color = if (enabled) cyan else muted) }
                }

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("EFFECTS", color = Color(0xFFF1F5F9), fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 2.sp, modifier = Modifier.weight(1f))
                        Text("${Show.entries.indexOf(activeShow) + 1} / ${Show.entries.size}", color = muted, fontSize = 11.sp)
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(end = 4.dp)) {
                        items(Show.entries) { show ->
                            Column(
                                Modifier.width(116.dp).clip(RoundedCornerShape(17.dp))
                                    .background(if (activeShow == show) Color(0xFF102129) else Color(0xFF0A0F15))
                                    .then(if (activeShow == show) Modifier else Modifier)
                                    .clickable { activeShow = show }.padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(Modifier.fillMaxWidth().height(58.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black)) {
                                    Canvas(Modifier.fillMaxSize()) { drawMiniPreview(show.kind) }
                                    if (activeShow == show) Text("✓", Modifier.align(Alignment.TopEnd).padding(5.dp), color = cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Text(show.label, color = if (activeShow == show) cyan else Color(0xFFE5ECF3), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                Text(show.subtitle, color = muted, fontSize = 9.sp, maxLines = 1)
                            }
                        }
                    }
                }

                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Color(0xFF0A0F15)).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("FINE TUNE", color = Color(0xFFF1F5F9), fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 2.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Brightness", color = Color(0xFFD8E0E8), fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Text("${(brightness * 100).toInt()}%", color = cyan, fontSize = 12.sp)
                    }
                    Slider(value = brightness, onValueChange = { brightness = it }, valueRange = 0.1f..0.8f, onValueChangeFinished = { scope.launch { context.flowPrefs.edit { it[KEY_BRIGHTNESS] = brightness } } })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Flow speed", color = Color(0xFFD8E0E8), fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Text(if (speed < 0.4f) "Slow" else if (speed < 0.75f) "Balanced" else "Fast", color = cyan, fontSize = 12.sp)
                    }
                    Slider(value = speed, onValueChange = { speed = it }, valueRange = 0.2f..1f)
                }

                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color(0xFF0A0F15)).padding(15.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Flip to activate", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text(if (sensorAvailable) "Start the show when the phone is face down" else "Accelerometer unavailable on this device", color = muted, fontSize = 11.sp, lineHeight = 15.sp)
                    }
                    Switch(checked = flipEnabled, enabled = sensorAvailable && enabled, onCheckedChange = {
                        flipEnabled = it; onFlipSettingChanged(it)
                        scope.launch { context.flowPrefs.edit { p -> p[KEY_FLIP] = it } }
                    })
                }

                Column(Modifier.fillMaxWidth().padding(top = 1.dp, bottom = 8.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("OLED CARE", color = Color(0xFFF1F5F9), fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 2.sp)
                    Text("The center stays pure black and the edge pattern keeps moving. Avoid leaving bright effects running unattended for long periods.", color = muted, fontSize = 11.sp, lineHeight = 17.sp)
                }
            }
        }
    }
}

@Composable
private fun EdgeShowCanvas(show: Show, enabled: Boolean, brightness: Float, speed: Float, modifier: Modifier = Modifier) {
    var time by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(enabled, speed) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L && enabled) time += ((now - last) / 1_000_000_000f) * speed * 0.75f
                last = now
            }
        }
    }
    Canvas(modifier.background(Color.Black)) {
        drawRect(Color.Black)
        if (enabled) drawFlowShow(show.kind, time, brightness.coerceIn(0.08f, 0.8f))
    }
}

private fun DrawScope.drawFlowShow(kind: Int, t: Float, power: Float) {
    val w = size.width
    val h = size.height
    // Narrow side rails are the only illuminated regions. The entire middle stays RGB(0,0,0).
    val rail = (w * 0.145f).coerceIn(22f, 68f)
    val palettes = listOf(
        listOf(Color(0xFF00EFFF), Color(0xFF477BFF)),
        listOf(Color(0xFF00EFFF), Color(0xFFB43DFF), Color(0xFFFF3EAD), Color(0xFF00EFFF)),
        listOf(Color(0xFFFF3D9A), Color(0xFF8C55FF), Color(0xFF35DFFF), Color(0xFFFF3D9A)),
        listOf(Color(0xFF00F5FF), Color(0xFFFF2CBF)),
        listOf(Color(0xFF7A5CFF), Color(0xFF00DFFF), Color(0xFF4CFFB5)),
        listOf(Color(0xFFFF3E9D), Color(0xFF7D5CFF), Color(0xFF00E8FF)),
        listOf(Color(0xFFB4FBFF), Color(0xFF24DFFF)),
        listOf(Color(0xFFFF4B9B), Color(0xFFFFD166), Color(0xFF4DFFB8), Color(0xFF36CFFF), Color(0xFF9D68FF))
    )
    val colors = palettes[kind.coerceIn(0, palettes.lastIndex)]
    val leftClip = Path().apply { moveTo(0f, 0f); lineTo(rail, 0f); lineTo(rail, h); lineTo(0f, h); close() }
    val rightClip = Path().apply { moveTo(w - rail, 0f); lineTo(w, 0f); lineTo(w, h); lineTo(w - rail, h); close() }

    // Each side uses the exact same coordinates mirrored horizontally: true mirror symmetry.
    for (side in 0..1) {
        val x0 = if (side == 0) 0f else w - rail
        clipPath(if (side == 0) leftClip else rightClip) {
            // A restrained edge haze gives the light something to reflect from without lighting the center.
            drawRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(Color.Transparent, colors[0].copy(alpha = power * 0.10f), Color.Transparent),
                    startX = x0, endX = x0 + rail
                ),
                topLeft = Offset(x0, 0f), size = Size(rail, h)
            )

            val lanes = when (kind) { 0, 6 -> 2; 1, 3 -> 4; 7 -> 5; else -> 3 }
            val laneWidth = (rail * when (kind) { 0, 6 -> 0.26f; 1, 3 -> 0.15f; else -> 0.19f }).coerceAtLeast(4f)
            val laneGap = (rail - laneWidth * lanes) / (lanes + 1)
            val speedFactor = when (kind) { 3 -> 1.55f; 6 -> 0.48f; 7 -> 1.25f; else -> 0.82f }
            val period = h * when (kind) { 0 -> 0.72f; 1 -> 0.54f; 3 -> 0.40f; 6 -> 0.90f; else -> 0.62f }

            for (lane in 0 until lanes) {
                val laneX = laneGap + lane * (laneWidth + laneGap)
                val mirroredX = if (side == 0) x0 + laneX else x0 + rail - laneX - laneWidth
                val lanePhase = lane * 0.19f
                val segments = when (kind) { 0, 6 -> 2; 1 -> 3; 3 -> 4; 7 -> 3; else -> 3 }
                for (segment in 0 until segments) {
                    val baseHeight = when (kind) {
                        0 -> h * 0.105f
                        1 -> h * (if (segment % 2 == 0) 0.075f else 0.12f)
                        3 -> h * 0.055f
                        6 -> h * 0.17f
                        else -> h * (0.065f + ((lane + segment) % 3) * 0.022f)
                    }
                    val gap = h * when (kind) { 3 -> 0.055f; 6 -> 0.12f; else -> 0.075f }
                    val stride = baseHeight + gap
                    val offset = (t * speedFactor * h * 0.42f + lanePhase * h + segment * stride * 1.75f) % (h + stride)
                    val y = offset - baseHeight
                    val color = colors[(lane + segment + if (kind == 2 || kind == 4 || kind == 7) (t * 0.18f).toInt() else 0) % colors.size]
                    val alphaWave = if (kind == 3) 0.62f + 0.38f * ((fsin(t * 3.4f + lane + segment) + 1f) / 2f) else 0.72f + 0.20f * ((fsin(t * 1.3f + lane * 0.8f + segment) + 1f) / 2f)
                    val rectHeight = if (kind == 5 && segment == 1) baseHeight * (0.6f + 0.4f * ((fsin(t + lane) + 1f) / 2f)) else baseHeight
                    // Glow and crisp rectangular core. No organic ribbons: the shape stays geometric.
                    if (y + rectHeight >= 0f && y <= h) {
                        drawRoundRect(
                            color = color.copy(alpha = power * 0.18f * alphaWave),
                            topLeft = Offset(mirroredX - laneWidth * 0.28f, y - 2f),
                            size = Size(laneWidth * 1.56f, rectHeight + 4f),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(laneWidth * 0.18f)
                        )
                        drawRoundRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(color.copy(alpha = power * alphaWave), color.copy(alpha = power * 0.68f * alphaWave)),
                                startY = y, endY = y + rectHeight
                            ),
                            topLeft = Offset(mirroredX, y),
                            size = Size(laneWidth, rectHeight),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(laneWidth * 0.12f)
                        )
                        // A small bright cap makes each block read as a luminous segment.
                        drawRect(
                            color = Color.White.copy(alpha = power * 0.40f * alphaWave),
                            topLeft = Offset(mirroredX + laneWidth * 0.18f, y + rectHeight * 0.12f),
                            size = Size(laneWidth * 0.64f, (rectHeight * 0.055f).coerceAtLeast(1.2f))
                        )
                    }
                }
            }

            // Occasional long geometric rails connect the moving blocks into coordinated patterns.
            if (kind == 2 || kind == 5 || kind == 7) {
                val connectorX = x0 + rail * if (side == 0) 0.12f else 0.88f
                for (i in 0..2) {
                    val connectorY = ((t * h * (0.24f + i * 0.05f) + i * h * 0.37f) % (h + 24f)) - 12f
                    drawRect(
                        color = colors[(i + kind) % colors.size].copy(alpha = power * 0.55f),
                        topLeft = Offset(connectorX - 1.2f, connectorY),
                        size = Size(2.4f, h * 0.11f)
                    )
                }
            }
        }
    }
    // Hard black center: never draw glow or color into the middle field.
    drawRect(Color.Black, topLeft = Offset(rail, 0f), size = Size(w - rail * 2f, h))
}

private fun DrawScope.drawMiniPreview(kind: Int) {
    drawRect(Color.Black)
    val colors = when (kind) {
        1 -> listOf(Color.Cyan, Color.Magenta, Color(0xFFFF4B9B))
        2 -> listOf(Color(0xFFFF3D9A), Color(0xFF8C55FF), Color.Cyan)
        3 -> listOf(Color.Cyan, Color.Magenta)
        4 -> listOf(Color(0xFF7A5CFF), Color.Cyan, Color(0xFF4CFFB5))
        6 -> listOf(Color(0xFFB4FBFF), Color.Cyan)
        7 -> listOf(Color(0xFFFF4B9B), Color(0xFFFFD166), Color.Cyan)
        else -> listOf(Color.Cyan, Color(0xFF477BFF), Color.Magenta)
    }
    val railW = size.width * 0.23f
    for (side in 0..1) {
        val x0 = if (side == 0) 0f else size.width - railW
        for (lane in 0..1) {
            val lx = x0 + lane * railW * 0.52f + 1f
            for (segment in 0..2) {
                val y = ((segment * size.height * 0.38f) + lane * 7f) % size.height
                val x = if (side == 0) lx else size.width - (lx - x0) - 3f
                drawRoundRect(colors[(lane + segment) % colors.size], Offset(x, y), Size(3f, 7f), androidx.compose.ui.geometry.CornerRadius(1f))
            }
        }
    }
}

internal fun fsin(value: Float): Float = kotlin.math.sin(value.toDouble()).toFloat()
internal fun fcos(value: Float): Float = kotlin.math.cos(value.toDouble()).toFloat()
