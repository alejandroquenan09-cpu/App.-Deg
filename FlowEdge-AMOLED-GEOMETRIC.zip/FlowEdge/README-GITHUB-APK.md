# Generar el APK de FlowEdge desde GitHub (sin computador)

El flujo de GitHub Actions puede compilar el proyecto en los servidores de GitHub. No se ha afirmado que compile hasta que una ejecución real termine correctamente.

## Si tu repositorio solo tiene `FlowEdge-AMOLED.zip`

1. En GitHub abre el repositorio en Chrome.
2. Pulsa **Add file → Create new file**.
3. Como nombre escribe exactamente `.github/workflows/build-apk.yml`.
4. Pega el contenido del archivo `build-apk.yml` que acompaña este paquete (también está en `.github/workflows/build-apk.yml` dentro del proyecto).
5. Pulsa **Commit changes**.
6. Abre la pestaña **Actions** y entra en **Build FlowEdge APK**.
7. Si no empezó automáticamente, pulsa **Run workflow → Run workflow**.
8. Abre la ejecución y espera a que termine. Si aparece una X roja, abre el paso que falló y revisa el mensaje.
9. Si termina con una marca verde, baja hasta **Artifacts** y descarga `FlowEdge-debug-APK`. Ese archivo descargado es un ZIP que contiene el APK.

El flujo detecta un ZIP en la raíz sin depender de su nombre exacto, lo descomprime y busca `settings.gradle.kts`. También puede compilar si los archivos del proyecto están directamente en la raíz del repositorio.

## Nota

Este repositorio no incluye Gradle Wrapper. El flujo instala Gradle 8.9 en el runner. Si la compilación falla por dependencias, SDK o código Kotlin, hay que corregir el error mostrado por GitHub Actions; crear el flujo no garantiza que el código compile.
