package com.flowedge.app

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.withFrameNanos
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs

private val Context.flowPrefs by preferencesDataStore(name = "flowedge_settings")
private val KEY_ENABLED = booleanPreferencesKey("enabled")
private val KEY_FLIP = booleanPreferencesKey("flip_enabled")
private val KEY_BRIGHTNESS = floatPreferencesKey("brightness")

class MainActivity : ComponentActivity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var flipEnabled = false
    private var systemEnabled = true
    private var upsideDownSince = 0L
    private var lastFlipTrigger = 0L
    private var onFlipDetected: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        setContent {
            FlowEdgeApp(
                onFlipSettingChanged = { flipEnabled = it; updateSensorRegistration() },
                onMasterChanged = { systemEnabled = it; updateSensorRegistration() },
                setFlipCallback = { onFlipDetected = it },
                sensorAvailable = accelerometer != null
            )
        }
    }

    private fun updateSensorRegistration() {
        sensorManager.unregisterListener(this)
        if (flipEnabled && systemEnabled && accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        val e = event ?: return
        if (e.sensor.type != Sensor.TYPE_ACCELEROMETER || !flipEnabled || !systemEnabled) return
        // Screen-down: gravity points approximately toward the display, so z is strongly negative on many devices.
        // Use a broad threshold and a dwell period to avoid reacting to brief movement.
        val now = System.currentTimeMillis()
        val down = e.values[2] < -7.5f && abs(e.values[0]) < 5.5f && abs(e.values[1]) < 5.5f
        if (down) {
            if (upsideDownSince == 0L) upsideDownSince = now
            if (now - upsideDownSince >= 1000 && now - lastFlipTrigger > 5000) {
                lastFlipTrigger = now
                onFlipDetected?.invoke()
            }
        } else upsideDownSince = 0L
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
    override fun onResume() { super.onResume(); updateSensorRegistration() }
    override fun onPause() { sensorManager.unregisterListener(this); super.onPause() }
}

private enum class Show(val label: String, val subtitle: String, val kind: Int) {
    WATERFALL("Waterfall", "Cascadas fluidas", 0), RAINBOW("Rainbow Flow", "Arcoíris líquido", 1), AURORA("Aurora", "Ondas polares", 2), NEON("Neon Pulse", "Pulsos de neón", 3), OCEAN("Ocean Waves", "Corrientes oceánicas", 4), CYBER("Cyberpunk", "Cian · magenta · violeta", 5), MINIMAL("Minimal Edge", "Línea de luz discreta", 6), GALAXY("Galaxy", "Partículas luminosas", 7)
}

@Composable
private fun FlowEdgeApp(
    onFlipSettingChanged: (Boolean) -> Unit,
    onMasterChanged: (Boolean) -> Unit,
    setFlipCallback: ((() -> Unit) -> Unit),
    sensorAvailable: Boolean
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs by context.flowPrefs.data.map { p -> Triple(p[KEY_ENABLED] ?: true, p[KEY_FLIP] ?: false, p[KEY_BRIGHTNESS] ?: 0.62f) }.collectAsState(initial = Triple(true, false, 0.62f))
    var enabled by remember { mutableStateOf(true) }
    var flipEnabled by remember { mutableStateOf(false) }
    var brightness by remember { mutableFloatStateOf(0.62f) }
    var speed by remember { mutableFloatStateOf(0.55f) }
    var activeShow by remember { mutableStateOf(Show.WATERFALL) }
    var demo by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf(0) }

    LaunchedEffect(prefs) {
        enabled = prefs.first; flipEnabled = prefs.second; brightness = prefs.third
        onMasterChanged(enabled); onFlipSettingChanged(flipEnabled)
    }
    setFlipCallback { if (enabled && flipEnabled) demo = true }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Color.Black, surface = Color(0xFF0C1017), surfaceVariant = Color(0xFF151C26),
        primary = Color(0xFF4DEBFF), secondary = Color(0xFFB56BFF), onBackground = Color(0xFFF3F7FA),
        onSurface = Color(0xFFF3F7FA), onSurfaceVariant = Color(0xFF9AA9B8)
    )) {
        Surface(Modifier.fillMaxSize(), color = Color.Black) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("FLOWEDGE", fontSize = 12.sp, color = Color(0xFF4DEBFF), fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                        Text("AMOLED LIGHT SHOW", fontSize = 23.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Text(if (enabled) "● ACTIVO" else "● PAUSADO", color = if (enabled) Color(0xFF4DEBFF) else Color.Gray, fontSize = 11.sp)
                }
                Spacer(Modifier.height(14.dp))
                Box(Modifier.fillMaxWidth().weight(if (selectedTab == 0) 0.88f else 0.32f).clip(RoundedCornerShape(24.dp)).background(Color.Black)) {
                    EdgeShowCanvas(show = activeShow, enabled = enabled && demo, brightness = brightness, speed = speed, modifier = Modifier.fillMaxSize())
                    if (!demo || !enabled) {
                        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("FLOW", fontSize = 13.sp, letterSpacing = 5.sp, color = Color(0xFF4DEBFF))
                            Text("Centro negro. Bordes vivos.", color = Color(0xFF7D8A98), fontSize = 12.sp)
                        }
                    }
                    Text(activeShow.label.uppercase(), Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp), color = Color(0xFFB6C4D2), fontSize = 10.sp, letterSpacing = 2.sp)
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { demo = true }, enabled = enabled, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text("▶  Mostrar") }
                    OutlinedButton(onClick = { demo = false }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text("■  Detener") }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFF0C1017)).padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("FlowEdge", fontWeight = FontWeight.Medium); Text("Interruptor maestro", fontSize = 11.sp, color = Color.Gray) }
                    Switch(checked = enabled, onCheckedChange = {
                        enabled = it; if (!it) demo = false
                        onMasterChanged(it); scope.launch { context.flowPrefs.edit { p -> p[KEY_ENABLED] = it } }
                    })
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFF0C1017)).padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("Efectos al poner boca abajo", fontWeight = FontWeight.Medium); Text(if (sensorAvailable) "Activación tras 1 segundo" else "Este dispositivo no informa acelerómetro", fontSize = 11.sp, color = Color.Gray) }
                    Switch(checked = flipEnabled, enabled = sensorAvailable && enabled, onCheckedChange = {
                        flipEnabled = it; onFlipSettingChanged(it)
                        scope.launch { context.flowPrefs.edit { p -> p[KEY_FLIP] = it } }
                    })
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf("Espectáculos", "Ajustes", "AMOLED").forEachIndexed { index, label ->
                        Box(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(if (selectedTab == index) Color(0xFF172630) else Color(0xFF0C1017)).clickable { selectedTab = index }.padding(vertical = 11.dp), contentAlignment = Alignment.Center) {
                            Text(label, color = if (selectedTab == index) Color(0xFF4DEBFF) else Color(0xFF9AA9B8), fontSize = 12.sp)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                when (selectedTab) {
                    0 -> LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                        items(Show.entries) { show ->
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(if (activeShow == show) Color(0xFF101E28) else Color(0xFF0A0D12)).clickable { activeShow = show }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Canvas(Modifier.size(width = 48.dp, height = 34.dp).clip(RoundedCornerShape(6.dp))) { drawMiniPreview(show.kind) }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) { Text(show.label, fontWeight = FontWeight.Medium, fontSize = 13.sp); Text(show.subtitle, color = Color.Gray, fontSize = 11.sp) }
                                if (activeShow == show) Text("✓", color = Color(0xFF4DEBFF))
                            }
                        }
                    }
                    1 -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Brillo máximo", color = Color(0xFFDCE6EF)); Slider(value = brightness, onValueChange = { brightness = it }, valueRange = 0.1f..0.8f, onValueChangeFinished = { scope.launch { context.flowPrefs.edit { p -> p[KEY_BRIGHTNESS] = brightness } } })
                        Text("Velocidad", color = Color(0xFFDCE6EF)); Slider(value = speed, onValueChange = { speed = it }, valueRange = 0.2f..1f)
                        Text("El brillo se limita en el motor gráfico. El ajuste no controla el brillo físico del sistema.", color = Color.Gray, fontSize = 11.sp)
                    }
                    else -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Protección activa durante la demostración", fontWeight = FontWeight.Medium)
                        Text("• Centro RGB negro puro.\n• Brillo del efecto limitado al 80 %.\n• Animación dinámica para reducir patrones fijos.\n• Detén el efecto cuando no lo estés mirando.", color = Color(0xFF9AA9B8), fontSize = 12.sp, lineHeight = 19.sp)
                        Text("Esto no elimina el riesgo de desgaste desigual en OLED. La app no puede sustituir el AOD del fabricante ni dibujar sobre una pantalla apagada.", color = Color(0xFFFFC875), fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun EdgeShowCanvas(show: Show, enabled: Boolean, brightness: Float, speed: Float, modifier: Modifier = Modifier) {
    var time by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(enabled, speed) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L && enabled) time += ((now - last) / 1_000_000_000f) * speed * 0.75f
                last = now
            }
        }
    }
    Canvas(modifier.background(Color.Black)) {
        drawRect(Color.Black)
        if (enabled) drawFlowShow(show.kind, time, brightness.coerceIn(0.08f, 0.8f))
    }
}

private fun DrawScope.drawFlowShow(kind: Int, t: Float, power: Float) {
    val w = size.width; val h = size.height
    val edgeW = (w * 0.16f).coerceIn(24f, 78f)
    val palette = when (kind) {
        1 -> listOf(Color(0xFFFF3C91), Color(0xFFFFC857), Color(0xFF65FFB8), Color(0xFF40D9FF), Color(0xFF9C68FF))
        2 -> listOf(Color(0xFF36FFB0), Color(0xFF25D9FF), Color(0xFF7A6CFF), Color(0xFFCB5BFF))
        3 -> listOf(Color(0xFF00F5FF), Color(0xFFB900FF), Color(0xFFFF2D91))
        4 -> listOf(Color(0xFF006DFF), Color(0xFF00E5FF), Color(0xFF52FFD2), Color(0xFF4A7DFF))
        5 -> listOf(Color(0xFF00F0FF), Color(0xFFFF2DCA), Color(0xFF8A4DFF))
        6 -> listOf(Color(0xFF00E5FF), Color(0xFFB0F9FF))
        7 -> listOf(Color(0xFF756BFF), Color(0xFF00D8FF), Color(0xFFFF5BCC))
        else -> listOf(Color(0xFF08D9FF), Color(0xFF695BFF), Color(0xFFFF4DCA), Color(0xFF40F4C6))
    }
    // Clip both independent light fields to the outer rails; everything between remains RGB(0,0,0).
    val leftClip = Path().apply { moveTo(0f, 0f); lineTo(edgeW, 0f); lineTo(edgeW, h); lineTo(0f, h); close() }
    val rightClip = Path().apply { moveTo(w-edgeW, 0f); lineTo(w, 0f); lineTo(w, h); lineTo(w-edgeW, h); close() }
    for (side in 0..1) {
        clipPath(if (side == 0) leftClip else rightClip) {
            val xBase = if (side == 0) 0f else w - edgeW
            if (kind == 6) {
                for (layer in 0..2) {
                    val x = xBase + edgeW * (0.12f + layer * 0.28f)
                    drawLine(palette[layer % palette.size].copy(alpha = power * (0.45f + 0.15f * fsin(t * 1.4f + layer))), Offset(x, 0f), Offset(x, h), strokeWidth = if (layer == 0) 2.2f else 1.1f)
                }
            } else {
                val ribbons = if (kind == 7) 20 else if (kind == 3) 11 else 15
                for (i in 0 until ribbons) {
                    val phase = i * 0.71f + side * 1.8f
                    val col = palette[i % palette.size]
                    val path = Path()
                    val center = xBase + edgeW * (0.18f + 0.65f * (0.5f + 0.5f * fsin(phase + t * (0.24f + i % 4 * 0.035f))))
                    val amp = edgeW * (if (kind == 0) 0.20f else 0.12f + (i % 3) * 0.035f)
                    val wave = (0.8f + 0.2f * fsin(t * 0.7f + phase))
                    path.moveTo(center, -30f)
                    val step = 12f
                    var y = -30f
                    while (y <= h + 30f) {
                        val yn = y / h
                        val flow = t * (if (kind == 3) 1.8f else if (kind == 0) 0.78f else 0.55f)
                        val drift = fsin(yn * 8.2f + flow + phase) * amp + fsin(yn * 18f - flow * 0.7f + phase * 1.7f) * amp * 0.42f
                        val x = center + drift * wave
                        if (y == -30f) path.moveTo(x, y) else path.lineTo(x, y)
                        y += step
                    }
                    val alpha = power * (if (kind == 3) 0.45f + 0.35f * (0.5f + 0.5f * fsin(t * 2.8f + phase)) else 0.25f + 0.3f * (0.5f + 0.5f * fsin(t + phase)))
                    drawPath(path, Brush.horizontalGradient(listOf(Color.Transparent, col.copy(alpha = alpha), palette[(i+1)%palette.size].copy(alpha = alpha * 0.75f), Color.Transparent), startX = xBase, endX = xBase + edgeW), style = Stroke(width = if (kind == 0) 3f + (i%3) else 2f + (i%4), cap = androidx.compose.ui.graphics.StrokeCap.Round))
                    // Broad soft glow under each moving filament gives the waterfall depth.
                    if (kind != 6 && i % 2 == 0) {
                        drawPath(path, col.copy(alpha = alpha * 0.12f), style = Stroke(width = edgeW * 0.16f, cap = androidx.compose.ui.graphics.StrokeCap.Round))
                    }
                }
                if (kind == 7) {
                    for (i in 0..18) {
                        val px = xBase + edgeW * (0.12f + ((i * 37) % 83) / 100f)
                        val py = ((i * 97f + t * (30f + i % 4 * 10f)) % (h + 20f)) - 10f
                        drawCircle(palette[i % palette.size].copy(alpha = power * 0.8f), radius = 1f + (i % 3), center = Offset(px, py))
                    }
                }
                if (kind == 4 || kind == 2) {
                    for (i in 0..4) {
                        val y = h * (0.12f + i * 0.19f) + fsin(t + i) * 12f
                        drawOval(Brush.horizontalGradient(listOf(Color.Transparent, palette[i % palette.size].copy(alpha = power * 0.18f), Color.Transparent), xBase, xBase + edgeW), topLeft = Offset(xBase, y - 13f), size = Size(edgeW, 26f))
                    }
                }
            }
        }
    }
    // Reassert the inner black field as a hard boundary against any glow/antialiasing spill.
    drawRect(Color.Black, topLeft = Offset(edgeW, 0f), size = Size(w - 2 * edgeW, h))
}

private fun DrawScope.drawMiniPreview(kind: Int) {
    drawRect(Color.Black)
    val colors = when (kind) { 1 -> listOf(Color.Magenta, Color.Yellow, Color.Cyan); 2 -> listOf(Color.Green, Color.Cyan, Color.Blue); 3 -> listOf(Color.Cyan, Color.Magenta); else -> listOf(Color.Cyan, Color(0xFF855BFF), Color.Magenta) }
    for (side in 0..1) {
        val x = if (side == 0) 0f else size.width - 7f
        for (i in 0..7) {
            val y = (i / 7f) * size.height
            drawLine(colors[i % colors.size].copy(alpha = 0.7f), Offset(x + fsin(i * 0.9f) * 3f, y), Offset(x + 5f + fcos(i * 0.7f) * 2f, y + 7f), strokeWidth = 2f)
        }
    }
}

internal fun fsin(value: Float): Float = kotlin.math.sin(value.toDouble()).toFloat()
internal fun fcos(value: Float): Float = kotlin.math.cos(value.toDouble()).toFloat()
