package com.flowedge.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AnimationMathTest {
    @Test fun sineRemainsInUnitRange() {
        for (i in -100..100) {
            val value = fsin(i / 10f)
            assertTrue(value >= -1.0001f && value <= 1.0001f)
        }
    }

    @Test fun cosineAtZeroIsOne() {
        assertEquals(1f, fcos(0f), 0.0001f)
    }
}
